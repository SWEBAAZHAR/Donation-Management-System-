package donationsystem;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class DonationSystem {
    private static Organization org = new Organization();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n===== Donation Management System =====");
            System.out.println("1. Add Donations");
            System.out.println("2. View All Donations");
            System.out.println("3. View Weekly Donations");
            System.out.println("4. View Monthly Donations");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addDonationLoop();
                    break;
                case 2:
                    display(org.getAllDonations());
                    break;
                case 3:
                    display(org.getWeeklyDonations());
                    break;
                case 4:
                    display(org.getMonthlyDonations());
                    break;
                case 5:
                    System.out.println("Exiting system... Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 5);
    }

    private static void addDonationLoop() {
        System.out.println("\nEnter donation details (type 'exit' to stop):");
        while (true) {
            System.out.print("Enter Donor Name: ");
            String name = sc.nextLine().trim();
            if (name.equalsIgnoreCase("exit")) break;

            System.out.print("Enter Account Number: ");
            String accNo = sc.nextLine();

            System.out.print("Enter Account Type: ");
            String accType = sc.nextLine();

            System.out.print("Enter Donation Amount: ");
            double amount = sc.nextDouble();
            sc.nextLine(); // consume newline

            Donor donor = new Donor(capitalize(name), accNo, capitalize(accType));
            LocalDate date = LocalDate.now();
            Donation donation = new Donation(donor, date, amount);
            org.addDonation(donation);

            System.out.println("Donation added successfully!\n");
        }
    }

    private static void display(List<Donation> list) {
        if (list.isEmpty()) {
            System.out.println("No donations found.");
            return;
        }
        System.out.printf("%-20s %-15s %-15s %-12s %-10s%n",
                "Donor Name", "Account No", "Account Type", "Date", "Amount");
        System.out.println("------------------------------------------------------------------");
        for (Donation d : list) {
            System.out.printf("%-20s %-15s %-15s %-12s %.2f%n",
                    d.getDonor().getName(),
                    d.getDonor().getAccountNo(),
                    d.getDonor().getAccountType(),
                    d.getDate(),
                    d.getAmount());
        }
    }

    private static String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        String[] words = str.toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }
} 
