package donationsystem;

import java.io.Serializable;
import java.time.LocalDate;

public class Donation implements Serializable {
    private static final long serialVersionUID = 1L;
    private Donor donor;
    private LocalDate date;
    private double amount;

    public Donation(Donor donor, LocalDate date, double amount) {
        this.donor = donor;
        this.date = date;
        this.amount = amount;
    }

    public Donor getDonor() {
        return donor;
    }

    public LocalDate getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }
}