package donationsystem;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Organization implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<Donation> donations = new ArrayList<>();

    public void addDonation(Donation donation) {
        donations.add(donation);
    }

    public List<Donation> getAllDonations() {
        return donations;
    }

    public List<Donation> getWeeklyDonations() {
        List<Donation> weekly = new ArrayList<>();
        LocalDate now = LocalDate.now();
        WeekFields wf = WeekFields.of(Locale.getDefault());
        int currentWeek = now.get(wf.weekOfWeekBasedYear());
        for (Donation d : donations) {
            int donationWeek = d.getDate().get(wf.weekOfWeekBasedYear());
            if (donationWeek == currentWeek && d.getDate().getYear() == now.getYear()) {
                weekly.add(d);
            }
        }
        return weekly;
    }

    public List<Donation> getMonthlyDonations() {
        List<Donation> monthly = new ArrayList<>();
        LocalDate now = LocalDate.now();
        int currentMonth = now.getMonthValue();
        int currentYear = now.getYear();
        for (Donation d : donations) {
            if (d.getDate().getMonthValue() == currentMonth && d.getDate().getYear() == currentYear) {
                monthly.add(d);
            }
        }
        return monthly;
    }
}