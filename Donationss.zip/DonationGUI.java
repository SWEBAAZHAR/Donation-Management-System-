package donationsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class DonationGUI extends JFrame {

    private Organization org =  new Organization();
    private JTextField nameField, accNoField, accTypeField, amountField;
    private JTable donationTable;
    private DefaultTableModel tableModel;
    private JLabel totalLabel;
    
  
    private static final String DATA_FILE = "donations.csv";

    public DonationGUI() {
        setTitle("Donation Management System");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

     
        loadDonationsFromTextFile();

     
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Enter Donation Details"));

        nameField = new JTextField();
        accNoField = new JTextField();
        accTypeField = new JTextField();
        amountField = new JTextField();

        JButton addButton = new JButton("Add Donation");
        addButton.addActionListener(e -> addDonation());

        inputPanel.add(new JLabel("Donor Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Account No:"));
        inputPanel.add(accNoField);
        inputPanel.add(new JLabel("Account Type:"));
        inputPanel.add(accTypeField);
        inputPanel.add(new JLabel("Donation Amount:"));
        inputPanel.add(amountField);
        inputPanel.add(new JLabel());
        inputPanel.add(addButton);

      
        String[] columns = {"Donor Name", "Account No", "Account Type", "Date", "Amount"};
        tableModel = new DefaultTableModel(columns, 0);
        donationTable = new JTable(tableModel);
        donationTable.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(donationTable);

        
        totalLabel = new JLabel("Total Donations: 0.00");
        totalLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        JButton weeklyButton = new JButton("Weekly Donations");
        weeklyButton.addActionListener(e -> displayDonations(org.getWeeklyDonations()));

        JButton monthlyButton = new JButton("Monthly Donations");
        monthlyButton.addActionListener(e -> displayDonations(org.getMonthlyDonations()));

        JButton allButton = new JButton("All Donations");
        allButton.addActionListener(e -> displayDonations(org.getAllDonations()));

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(allButton);
        bottomPanel.add(weeklyButton);
        bottomPanel.add(monthlyButton);
        bottomPanel.add(totalLabel);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

    
        displayDonations(org.getAllDonations());

       
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                saveDonationsToTextFile(); // New save method
            }
        });

        setVisible(true);
    }

    private void addDonation() {
        try {
            String name = capitalizeEachWord(nameField.getText().trim());
            String accNo = accNoField.getText().trim();
            String accType = capitalizeEachWord(accTypeField.getText().trim());
            String amountText = amountField.getText().trim();

            
            if (name.isEmpty() || accNo.isEmpty() || accType.isEmpty() || amountText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double amount = Double.parseDouble(amountText);

            if (amount <= 0) {
                JOptionPane.showMessageDialog(this, "Donation amount must be greater than zero.", "Invalid Amount", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Donor donor = new Donor(name, accNo, accType);
            Donation donation = new Donation(donor, LocalDate.now(), amount);
            org.addDonation(donation);

          
            saveDonationsToTextFile();

            displayDonations(org.getAllDonations());

         
            nameField.setText("");
            accNoField.setText("");
            accTypeField.setText("");
            amountField.setText("");

            JOptionPane.showMessageDialog(this, "Donation added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid donation amount. Please enter a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displayDonations(List<Donation> donations) {
        tableModel.setRowCount(0);
        double total = 0;
        for (Donation d : donations) {
            tableModel.addRow(new Object[]{
                    d.getDonor().getName(),
                    d.getDonor().getAccountNo(),
                    d.getDonor().getAccountType(),
                    d.getDate(),
                    String.format("%.2f", d.getAmount())
            });
            total += d.getAmount();
        }
        totalLabel.setText("Total Donations: " + String.format("%.2f", total));
    }

    private String capitalizeEachWord(String input) {
        if (input == null || input.isEmpty()) return input;
        String[] words = input.toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (!w.isEmpty()) {
                sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }
    

    private void saveDonationsToTextFile() {
        // Use PrintWriter and FileWriter for text output
        try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE))) {
            
         
            writer.println("Name,AccountNo,AccountType,Date,Amount");
            
            for (Donation d : org.getAllDonations()) {
                // Manually format the data into a comma-separated line (CSV)
                String line = String.format("%s,%s,%s,%s,%.2f",
                    d.getDonor().getName(),
                    d.getDonor().getAccountNo(),
                    d.getDonor().getAccountType(),
                    d.getDate().toString(),
                    d.getAmount()
                );
                writer.println(line);
            }
            System.out.println("Donations saved successfully to " + DATA_FILE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving donations: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    
    private void loadDonationsFromTextFile() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            System.out.println("No existing donation file found. Starting fresh.");
            return;
        }

      
        try (Scanner scanner = new Scanner(file)) {
            int loadedCount = 0;
            
            
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
             
                String[] parts = line.split(",");
                
                if (parts.length == 5) {
                    try {
                       
                        String name = parts[0].trim();
                        String accNo = parts[1].trim();
                        String accType = parts[2].trim();
                        LocalDate date = LocalDate.parse(parts[3].trim()); 
                        double amount = Double.parseDouble(parts[4].trim()); 
                        
                       
                        Donor donor = new Donor(name, accNo, accType);
                        Donation donation = new Donation(donor, date, amount);
                        org.addDonation(donation);
                        loadedCount++;
                        
                    } catch (NumberFormatException | DateTimeParseException e) {
                        System.err.println("Skipping malformed data line (parsing error): " + line + ". Error: " + e.getMessage());
                    }
                } else {
                    System.err.println("Skipping malformed line (incorrect part count): " + line);
                }
            }
            System.out.println("Loaded " + loadedCount + " donations from text file.");
        } catch (FileNotFoundException e) {
            
            JOptionPane.showMessageDialog(this, "Error loading donations: File not found.", "Load Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DonationGUI::new);
    }
}