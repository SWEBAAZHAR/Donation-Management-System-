package donationsystem;

import java.io.Serializable; // NEW import

public class Donor extends Person implements Serializable { // UPDATED signature
    private static final long serialVersionUID = 1L; // Recommended for serialization
    private String accountNo;
    private String accountType;

    public Donor(String name, String accountNo, String accountType) {
        super(name);
        this.accountNo = accountNo;
        this.accountType = accountType;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public String getAccountType() {
        return accountType;
    }
}